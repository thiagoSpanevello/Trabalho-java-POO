package com.ciscos.project.utils;

public class Damage {
    public final double damage;
    public final String type;

    public Damage(double damage, String type) {
        this.type = type;
        this.damage = damage;
    }
}
