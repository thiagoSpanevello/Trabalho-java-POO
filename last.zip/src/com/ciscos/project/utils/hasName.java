package com.ciscos.project.utils;

public interface hasName {
    public String getName();
}