package com.ciscos.project;

import com.ciscos.project.frames.Principal;

public class Ciscos {

    public static void main(String[] args) {
        Principal principal = new Principal();
        principal.setVisible(true);
        principal.setDefaultCloseOperation(Principal.EXIT_ON_CLOSE);
    }
}
