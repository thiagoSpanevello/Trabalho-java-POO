package com.mycompany.mavenproject2.Mage;

import com.mycompany.mavenproject2.Utils.hasName;

public class Spell implements hasName {

    private final int levelRequired;
    private final int mana;
    private final double damage;
    private final String name;
    private final double multiplier;

    public Spell(int levelRequired, int mana, double damage, String name, double multiplier) {
        this.levelRequired = levelRequired;
        this.mana = mana;
        this.damage = damage;
        this.name = name;
        this.multiplier = multiplier;
    }

    public int getLevelRequired() {
        return levelRequired;
    }

    public int getMana() {
        return mana;
    }

    public double getDamage() {
        return damage;
    }

    @Override
    public String getName() {
        return name;
    }

    public double getMultiplier() {
        return multiplier;
    }
}
