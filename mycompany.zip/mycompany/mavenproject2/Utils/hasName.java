package com.mycompany.mavenproject2.Utils;

public interface hasName {
    public String getName();
}