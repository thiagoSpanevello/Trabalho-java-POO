package com.mycompany.mavenproject2.Utils;

public class Damage {
    public final double damage;
    public final String type;

    public Damage(double damage, String type) {
        this.type = type;
        this.damage = damage;
    }
}
