/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.ciscos.project;

import com.ciscos.project.frames.Principal;

/**
 *
 * @author imakrp
 */
public class Ciscos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Principal principal = new Principal();
        principal.setVisible(true);
        principal.setDefaultCloseOperation(Principal.EXIT_ON_CLOSE);
    }
    
}
